package com.cg.service;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public interface IEBILLService {
	public String insert(BillDTO billDTO) throws BillUserException;
	

}
