package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;
import com.cg.service.EBILLServiceImpl;
import com.cg.service.IEBILLService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		final double FIXED_AMOUNT= 100;
		double netAmount = 0.0;
		double currentReading = Double.parseDouble(request.getParameter("currentReading"));
		double lastReading = Double.parseDouble(request.getParameter("lastReading"));
		double unitsConsumed =   currentReading - lastReading;
		
		int consumerNo = Integer.parseInt(request.getParameter("consumerNo"));
		netAmount = unitsConsumed * 1.15 + FIXED_AMOUNT;
		
		BillDTO billDTO = new BillDTO();
		billDTO.setConsumerNum(consumerNo);
		billDTO.setCurrentReading(currentReading);
		billDTO.setUnitConsumed(unitsConsumed);
		billDTO.setNetAmount(netAmount);
		
		IEBILLService eBillService = new EBILLServiceImpl();
		try{
		String name = eBillService.insert(billDTO);
		out.print("Bill Inserted successfully for " + name);
		}catch(BillUserException e)
		{
			out.println("Couldn't insert record.");
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
