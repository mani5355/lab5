package com.cg.dao;

public interface IQueryMapperEBill {
	public static final String INSERT_BILL = "INSERT INTO billdetails VALUES (seq_bill_num.NEXTVAL,"
			+ " ?,?,?,?,SYSDATE)";
	public static final String GET_CONSUMER = "SELECT consumer_name FROM consumers WHERE consumer_num = ?";	
}
