package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public class EBillDAOImpl implements IEBillDAO {

	@Override
	public boolean insert(BillDTO billDTO) throws BillUserException {
		boolean  isInserted = false;
		try{
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource)ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperEBill.INSERT_BILL);
			
			st.setInt(1, billDTO.getConsumerNum());
			st.setDouble(2, billDTO.getCurrentReading());
			st.setDouble(3, billDTO.getUnitConsumed());
			st.setDouble(4, billDTO.getNetAmount());
			
			int records = st.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
			
			
		}catch(NamingException | SQLException e){
			throw new BillUserException(e.getMessage());
		}
		return isInserted;
	}

	@Override
	public String getConsNAme(int consumerNo) throws BillUserException {
		String consName = null;
		try{
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource)ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			PreparedStatement st = con.prepareStatement(IQueryMapperEBill.GET_CONSUMER);
			
			st.setInt(1, consumerNo);
			ResultSet rs = st.executeQuery();
			
			if(rs.next()){
				consName = rs.getString(1);
			}
			
			
		}catch(NamingException | SQLException e){
			throw new BillUserException(e.getMessage());
		}
		return consName;
	}

}
