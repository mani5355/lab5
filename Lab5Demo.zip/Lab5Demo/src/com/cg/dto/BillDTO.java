package com.cg.dto;

import java.sql.Date;

public class BillDTO {
	private int billNUM;
	private int consumerNum;
	private double currentReading;
	private double unitConsumed;
	private double netAmount;
	private Date bill_date;
	public BillDTO() {
		super();
	}
	public BillDTO(int consumerNum, double currentReading,
			double unitConsumed, double netAmount) {
		super();
		this.consumerNum = consumerNum;
		this.currentReading = currentReading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
	}
	public int getBillNUM() {
		return billNUM;
	}
	
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}
	public double getCurrentReading() {
		return currentReading;
	}
	public void setCurrentReading(double currentReading) {
		this.currentReading = currentReading;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}
	@Override
	public String toString() {
		return "BillDTO [billNUM=" + billNUM + ", consumerNum=" + consumerNum
				+ ", currentReading=" + currentReading + ", unitConsumed="
				+ unitConsumed + ", netAmount=" + netAmount + ", bill_date="
				+ bill_date + "]";
	}
	
	
	
	

}
